package Main;
import modelo.*;
//import Interfaz.*;

public class Test {
    public static void main(String[] args) {

        MiembroDeMesa obj1 = new MiembroDeMesa("David", 100, "presidente");
        MiembroDeMesa obj2 = new MiembroDeMesa("Maria", 200, "secretario");
        MiembroDeMesa obj3 = new MiembroDeMesa("Jose", 300, "vocal");
        
        MiembroDeMesa[] miembros = new MiembroDeMesa[3];
        
        MiembroDeMesa obj4 = new MiembroDeMesa("David2", 400, "presidente");
        MiembroDeMesa obj5 = new MiembroDeMesa("Maria2", 500, "secretario");
        MiembroDeMesa obj6 = new MiembroDeMesa("Jose2", 600, "vocal");
        
        MiembroDeMesa[] miembros2 = new MiembroDeMesa[3];
        
        miembros[0] = obj1;
        miembros[1] = obj2;
        miembros[2] = obj3;
        miembros2[0] = obj4;
        miembros2[1] = obj5;
        miembros2[2] = obj6;
        
        MesaElectoral mesa1 = new MesaElectoral("centro", 10, miembros);
        MesaElectoral mesa2 = new MesaElectoral("sur", 20, miembros2);
        //System.out.println(mesa1);
        
        MesaElectoral[] mesas = new MesaElectoral[2];
        
        mesas[0] = mesa1;
        mesas[1] = mesa2;
        
        Candidato cand1 = new Candidato("Martin", 1000, "Accion Popular");
        Candidato cand2 = new Candidato("Lopez", 2000, "Accion Popular");
        
        Candidato[] candidatos = new Candidato[2];
        
        candidatos[0] = cand1;
        candidatos[1] = cand2;
        
        PartidoPolitico partido1 = new PartidoPolitico("Accion Popular", "Angelo", 001);
        PartidoPolitico[] partidos = new PartidoPolitico[1];
        partidos[0] = partido1;
        //System.out.println(partido1);
        
        int[] votos1 = new int[2];
        votos1[0] = 0;
        votos1[1] = 90;
        
        int[] votos2 = new int[2];
        votos2[0] = 63;
        votos2[1] = 57;
        
        ActaElectoral acta1 = new 
        ActaElectoral("Acta 1", 01, "01-01-2001", 100, 90, 5, 5, "www", "ninguna observacion", miembros, votos1);
        
        ActaElectoral acta2 = new 
        ActaElectoral("Acta 2", 02, "01-01-2001", 150, 110, 20, 20, "www", "ninguna observacion", miembros2, votos2);
        //System.out.println(acta1);
        
        ActaElectoral[] actas = new ActaElectoral[2];
        actas[0] = acta1;
        actas[1] = acta2;
        
        Eleccion eleccion1 = new Eleccion("Municipal", "01-01-2001", 1001, candidatos, partidos, mesas, actas);
        //System.out.println(eleccion1);
        //Eleccion eleccion2 = new Eleccion("Regional", "01-01-2001", 1001, candidatos, partidos, mesas, actas);
        
        Eleccion[] elecciones = new Eleccion[1];
        elecciones[0] = eleccion1;
        //elecciones[1] = eleccion1;
        
        
        Operador operador1 = new Operador("admin", "1234", elecciones);
        //System.out.println(operador1);
        
        
        String a = operador1.hallarGanador();
        //System.out.println(a);
    }
    
}
