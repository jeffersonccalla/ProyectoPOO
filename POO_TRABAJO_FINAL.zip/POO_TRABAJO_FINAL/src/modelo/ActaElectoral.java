package modelo;
public class ActaElectoral {

    //Atributos de la clase ActaElectoral
    private String titulo;
    private int nroActaUnico;
    private String fecha;
    private int cantVotos;
    private int cantVotosValidos;
    private int cantVotosNulos;
    private int cantVotosBlanco;
    private String firma;
    private String observacion;
    private MiembroDeMesa[] miembros;
    private int[] votoCandidato;
    
    public ActaElectoral(){
        titulo = "";
        nroActaUnico = 0;
        fecha = "";
        cantVotos = 0;
        cantVotosValidos = 0;
        cantVotosNulos = 0;
        cantVotosBlanco = 0;
        firma = "";
        observacion = "";
        miembros = new MiembroDeMesa[0];
        votoCandidato = new int[0];
    }

    public ActaElectoral(String titulo, 
                        int nroActaUnico, 
                        String fecha, 
                        int cantVotos, 
                        int cantVotosValidos, 
                        int cantVotosNulos, 
                        int cantVotosBlanco, 
                        String firma, 
                        String observacion, 
                        MiembroDeMesa[] miembros, 
                        int[] votoCandidato) {
        this.titulo = titulo;
        this.nroActaUnico = nroActaUnico;
        this.fecha = fecha;
        this.cantVotos = cantVotos;
        this.cantVotosValidos = cantVotosValidos;
        this.cantVotosNulos = cantVotosNulos;
        this.cantVotosBlanco = cantVotosBlanco;
        this.firma = firma;
        this.observacion = observacion;
        this.miembros = miembros;
        this.votoCandidato = votoCandidato;
    }
    
    //Get's y Set's

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public int getNroActaUnico() {
        return nroActaUnico;
    }

    public void setNroActaUnico(int nroActaUnico) {
        this.nroActaUnico = nroActaUnico;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getCantVotos() {
        return cantVotos;
    }

    public void setCantVotos(int cantVotos) {
        this.cantVotos = cantVotos;
    }

    public int getCantVotosValidos() {
        return cantVotosValidos;
    }

    public void setCantVotosValidos(int cantVotosValidos) {
        this.cantVotosValidos = cantVotosValidos;
    }

    public int getCantVotosNulos() {
        return cantVotosNulos;
    }

    public void setCantVotosNulos(int cantVotosNulos) {
        this.cantVotosNulos = cantVotosNulos;
    }

    public int getCantVotosBlanco() {
        return cantVotosBlanco;
    }

    public void setCantVotosBlanco(int cantVotosBlanco) {
        this.cantVotosBlanco = cantVotosBlanco;
    }

    public String getFirma() {
        return firma;
    }

    public void setFirma(String firma) {
        this.firma = firma;
    }

    public String getObservacion() {
        return observacion;
    }

    public void setObservacion(String observacion) {
        this.observacion = observacion;
    }

    public MiembroDeMesa[] getMiembros() {
        return miembros;
    }

    public void setMiembros(MiembroDeMesa[] miembros) {
        this.miembros = miembros;
    }

    public int[] getVotoCandidato() {
        return votoCandidato;
    }

    public void setVotoCandidato(int[] votoCandidato) {
        this.votoCandidato = votoCandidato;
    }
    
    //toString
    @Override
    public String toString() {
        
        String miembrosString = "";
        String votoCandidatoString = "";
        
        for (int i = 0; i < miembros.length; i++) {
            miembrosString += "\n\t\t\t\t\t" + miembros[i];
        }
        
        for (int j = 0; j < votoCandidato.length; j++) {
            votoCandidatoString += " " + votoCandidato[j];
        }
        
        return "ActaElectoral{" + 
                
                                "\n\t\t\t\ttitulo=" + titulo + 
                                "\n\t\t\t\tnroActaUnico=" + nroActaUnico +
                                "\n\t\t\t\tfecha=" + fecha + 
                                "\n\t\t\t\tcantVotos=" + cantVotos +
                                "\n\t\t\t\tcantVotosValidos=" + cantVotosValidos + 
                                "\n\t\t\t\tcantVotosNulos=" + cantVotosNulos + 
                                "\n\t\t\t\tcantVotosBlanco=" + cantVotosBlanco + 
                                "\n\t\t\t\tfirma=" + firma + 
                                "\n\t\t\t\tobservacion=" + observacion +
                                "\n\t\t\t\tmiembros=" + miembrosString + 
                                "\n\t\t\t\tvotoCandidato={" + votoCandidatoString + "}\n}";
    }
    
    
    
}
