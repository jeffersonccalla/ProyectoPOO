package modelo;
public class Candidato {
        
    //Atributos de la Clase ActaElectoral
    private String nombre;
    private int Dni;
    private String nombrePartido;

    
    //Metodos Constructores default/sobrecargado
    public Candidato() {
        nombre = "";
        Dni = 0;
        nombrePartido = "";
    }

    public Candidato(String nombre, int Dni, String nombrePartido) {
        this.nombre = nombre;
        this.Dni = Dni;
        this.nombrePartido = nombrePartido;
    }

    //Get's y Set's
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDni() {
        return Dni;
    }

    public void setDni(int Dni) {
        this.Dni = Dni;
    }

    public String getNombrePartido() {
        return nombrePartido;
    }

    public void setNombrePartido(String nombrePartido) {
        this.nombrePartido = nombrePartido;
    }

    @Override
    public String toString() {
        return "Candidato{" + "nombre=" + nombre + ", Dni=" + Dni + ", nombrePartido=" + nombrePartido + '}';
    }

    
    
}
