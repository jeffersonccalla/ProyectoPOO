package modelo;
public class Eleccion {
    
    //Atributos de la clase Eleccion
    private String tipo;
    private String fecha;
    private int nroEleccion;
    private Candidato[] candidatos;
    private PartidoPolitico[] partidosPoliticos;
    private MesaElectoral[] mesasElectorales;
    private ActaElectoral[] actasElectorales;
    
    //Metodos Constructores default/sobrecargado
    public Eleccion(){
        tipo = "";
        fecha = "";
        nroEleccion = 0;
        candidatos = new Candidato[0];
        partidosPoliticos = new PartidoPolitico[0];
        mesasElectorales = new MesaElectoral[0];
        actasElectorales = new ActaElectoral[0];
    }

    public Eleccion(
            String tipo, 
            String fecha, 
            int nroEleccion, 
            Candidato[] candidatos, 
            PartidoPolitico[] partidosPoliticos, 
            MesaElectoral[] mesasElectorales, 
            ActaElectoral[] actasElectorales) {
        this.tipo = tipo;
        this.fecha = fecha;
        this.nroEleccion = nroEleccion;
        this.candidatos = candidatos;
        this.partidosPoliticos = partidosPoliticos;
        this.mesasElectorales = mesasElectorales;
        this.actasElectorales = actasElectorales;
    }
    
    //Get's y Set's
    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public int getNroEleccion() {
        return nroEleccion;
    }

    public void setNroEleccion(int nroEleccion) {
        this.nroEleccion = nroEleccion;
    }

    public Candidato[] getCandidatos() {
        return candidatos;
    }

    public void setCandidatos(Candidato[] candidatos) {
        this.candidatos = candidatos;
    }

    public PartidoPolitico[] getPartidosPoliticos() {
        return partidosPoliticos;
    }

    public void setPartidosPoliticos(PartidoPolitico[] partidosPoliticos) {
        this.partidosPoliticos = partidosPoliticos;
    }

    public MesaElectoral[] getMesasElectorales() {
        return mesasElectorales;
    }

    public void setMesasElectorales(MesaElectoral[] mesasElectorales) {
        this.mesasElectorales = mesasElectorales;
    }

    public ActaElectoral[] getActasElectorales() {
        return actasElectorales;
    }

    public void setActasElectorales(ActaElectoral[] actasElectorales) {
        this.actasElectorales = actasElectorales;
    }
    
    //ToString
    @Override
    public String toString() {
        
        String candidatosString = "";
        String partidosPoliticosString = "";
        String mesasElectoralesString = "";
        String actasElectoralesString = "";
        
        for (int i = 0; i < candidatos.length; i++) {
            candidatosString += "\n\t\t\t" + candidatos[i];
        }
        
        for (int j = 0; j < partidosPoliticos.length; j++) {
            partidosPoliticosString += "\n\t\t\t" + partidosPoliticos[j];
        }
        
        for (int k = 0; k < mesasElectorales.length; k++) {
            mesasElectoralesString += "\n\t\t\t" + mesasElectorales[k];
        }
        
        for (int p = 0; p < actasElectorales.length; p++) {
            actasElectoralesString += "\n\t\t\t" + actasElectorales[p];
        }
        
        return "Eleccion{" + 
                
                "\n\ttipo=" + tipo + 
                "\n\tfecha=" + fecha + 
                "\n\tnroEleccion=" + nroEleccion + 
                "\n\tcandidatos=" + candidatosString + 
                "\n\tpartidosPoliticos=" + partidosPoliticosString + 
                "\n\tmesasElectorales=" + mesasElectoralesString + 
                "\n\tactasElectorales=" + actasElectoralesString + '}';
    }
    
    
    //Metodo para agregar Candidatos
    
    public void agregarCandidato(Candidato candidato){
        
        Candidato[] newCandidatos = new Candidato[candidatos.length+1];
        
        for (int i = 0; i < candidatos.length; i++) {
            newCandidatos[i] = candidatos[i];
        }
        
        newCandidatos[candidatos.length] = candidato;
        this.candidatos = newCandidatos;
        
    }
    
    public void agregarPartido(PartidoPolitico partido){
        
        
        PartidoPolitico[] newPartidos = new PartidoPolitico[partidosPoliticos.length+1];
        
        for (int i = 0; i < partidosPoliticos.length; i++) {
            newPartidos[i] = partidosPoliticos[i];
        }
        newPartidos[partidosPoliticos.length] = partido;
        this.partidosPoliticos = newPartidos;
        
    }
    
    public void agregarMesa(MesaElectoral mesa){
        
        MesaElectoral[] newMesas = new MesaElectoral[mesasElectorales.length + 1];
        
        for (int i = 0; i < mesasElectorales.length; i++) {
           newMesas[i] = mesasElectorales[i];
        }
        
        newMesas[mesasElectorales.length] = mesa;
        this.mesasElectorales = newMesas;
    }
    
    public void agregarPresidente(MiembroDeMesa miembro, int nroMesa){
        
        this.mesasElectorales[nroMesa].getMiembros()[0] = miembro;
        
    }
    
    public void agregarSecretario(MiembroDeMesa miembro, int nroMesa){
        this.mesasElectorales[nroMesa].getMiembros()[1] = miembro;
    }
    
    public void agregarVocal(MiembroDeMesa miembro, int nroMesa){
        this.mesasElectorales[nroMesa].getMiembros()[2] = miembro;
    }
    
    
    
}
