package modelo;
public class MesaElectoral {

    //Atributos de la clase MesaElectoral
    private String lugar;
    private int nroMesa;
    private MiembroDeMesa[] miembros;
    
    //Metodos Constructores default/sobrecargado
    public MesaElectoral() {
        lugar = "";
        nroMesa = 0;
        miembros = new MiembroDeMesa[3];
        
        for (int i = 0; i < 3; i++) {
            miembros[i] = new MiembroDeMesa();
        }
    }

    public MesaElectoral(String lugar, int nroMesa, MiembroDeMesa[] miembros) {
        this.lugar = lugar;
        this.nroMesa = nroMesa;
        this.miembros = miembros;
    }
    
    //Get's y Set's
    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public int getNroMesa() {
        return nroMesa;
    }

    public void setNroMesa(int nroMesa) {
        this.nroMesa = nroMesa;
    }

    public MiembroDeMesa[] getMiembros() {
        return miembros;
    }

    public void setMiembros(MiembroDeMesa[] miembros) {
        this.miembros = miembros;
    }
    
    //ToString
    @Override
    public String toString() {
        String miembrosString = "";
        for (int i = 0; i < miembros.length; i++) {
            miembrosString = miembrosString + "\n\t\t\t\t"+miembros[i];
        }
        
        return "MesaElectoral{" + 
                
                "\n\t\t\tlugar=" + lugar + 
                "\n\t\t\tnroMesa=" + nroMesa + 
                "\n\t\t\tmiembros=" + miembrosString + '}';
    }
    
}
