package modelo;
public class MiembroDeMesa {
    
    //Atributos de la clase MiembroDeMesa
    private String nombre;
    private int Dni;
    private String tipoMiembro;
    
    //Metodo Constructor default/sobrecargado
    public MiembroDeMesa() {
        nombre = "";
        Dni = 0;
        tipoMiembro = "";
    }

    public MiembroDeMesa(String nombre, int Dni, String tipoMiembro) {
        this.nombre = nombre;
        this.Dni = Dni;
        this.tipoMiembro = tipoMiembro;
    }
    
    //Get's y Set's

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getDni() {
        return Dni;
    }

    public void setDni(int Dni) {
        this.Dni = Dni;
    }

    public String getTipoMiembro() {
        return tipoMiembro;
    }

    public void setTipoMiembro(String tipoMiembro) {
        this.tipoMiembro = tipoMiembro;
    }
    
    //ToString

    @Override
    public String toString() {
        return "MiembroDeMesa{" + "nombre=" + nombre + ", Dni=" + Dni + ", tipoMiembro=" + tipoMiembro + '}';
    }
    
}
