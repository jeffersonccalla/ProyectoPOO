package modelo;
public class Operador {
    
    //Atributos del Operador
    private String user;
    private String contrasena;
    private Eleccion[] elecciones;
    
    //Metodos Constructores default/sobrecargado
    public Operador(){
        user = "";
        contrasena = "";
        elecciones = new Eleccion[0];
    }

    public Operador(String user, String contrasena, Eleccion[] elecciones) {
        this.user = user;
        this.contrasena = contrasena;
        this.elecciones = elecciones;
    }
    
    //Get's y Set's
    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getContrasena() {
        return contrasena;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public Eleccion[] getElecciones() {
        return elecciones;
    }

    public void setElecciones(Eleccion[] elecciones) {
        this.elecciones = elecciones;
    }
    
    //ToString
    @Override
    public String toString() {
        
        String eleccionesString = "";
        
        for (int i = 0; i < elecciones.length; i++) {
            eleccionesString += "\n\n\t" + elecciones[i];
        }
        
        return "Operador{" + 
                
                "\n\tuser=" + user + 
                "\n\tcontrasena=" + contrasena + 
                "\n\telecciones=" + eleccionesString + '}';
    }
    
    //Otros Metodos
    
    public String hallarGanador(){
        
        int cantCandidatos = 0;
        int votosMax = 0;
        int aux = 0;
        cantCandidatos = elecciones[0].getCandidatos().length;
        
        ActaElectoral[] array = elecciones[0].getActasElectorales();
        Candidato[] array2 = elecciones[0].getCandidatos();
        int[] votos = new int[cantCandidatos];

        
        for (int j = 0; j < array.length; j++) {
            
            for (int p = 0; p < votos.length; p++) {
                votos[p] += array[j].getVotoCandidato()[0];
            }
        }

        for (int i = 0; i < cantCandidatos; i++) {
            
            if(votosMax<votos[i]){
                votosMax = votos[i];
                aux = i;
            }
        }
        
        String cand = array2[aux].getNombre();
        String vot = votosMax + "";
        
        return "El candidato " + cand + " gano con: " + vot + " votos!";
        
    }
    
    
}
