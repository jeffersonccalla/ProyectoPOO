package modelo;
public class PartidoPolitico {
    
    //Atrivutos de la clase PartidoPolitico
    private String nombrePartido;
    private String representanteNombre;
    private int representanteDni;


    //Metodos Constructores default/sobrecargado
    public PartidoPolitico() {
        nombrePartido = "";
        representanteNombre = "";
        representanteDni = 0;

    }

    public PartidoPolitico(String nombrePartido, String representanteNombre, int representanteDni) {
        this.nombrePartido = nombrePartido;
        this.representanteNombre = representanteNombre;
        this.representanteDni = representanteDni;

    }
    
    //Get's y Set's
    public String getNombrePartido() {
        return nombrePartido;
    }

    public void setNombrePartido(String nombrePartido) {
        this.nombrePartido = nombrePartido;
    }

    public String getRepresentanteNombre() {
        return representanteNombre;
    }

    public void setRepresentanteNombre(String representanteNombre) {
        this.representanteNombre = representanteNombre;
    }

    public int getRepresentanteDni() {
        return representanteDni;
    }

    public void setRepresentanteDni(int representanteDni) {
        this.representanteDni = representanteDni;
    }

    
    
    //ToString
    @Override
    public String toString() {
        
        return "PartidoPolitico{" + 
                
                "\n\t\t\t\t\tnombrePartido=" + nombrePartido + 
                "\n\t\t\t\t\trepresentanteNombre=" + representanteNombre + 
                "\n\t\t\t\t\trepresentanteDni=" + representanteDni  
                 + '}';
    }
    
}
